import React from 'react'

export default function GuestPage() {
  return (
    <div>방명록</div>
  )
}
