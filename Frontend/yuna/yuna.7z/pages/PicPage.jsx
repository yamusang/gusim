import React from 'react'

export default function PicPage() {
  return (
    <div>갤러리</div>
  )
}
